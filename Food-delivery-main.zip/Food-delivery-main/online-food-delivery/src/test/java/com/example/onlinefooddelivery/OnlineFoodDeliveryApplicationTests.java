package com.example.onlinefooddelivery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineFoodDeliveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
